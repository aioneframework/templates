*This repo is not maintained anymore. Open an issue and let me know if you want to adopt it.*

ThemeForest Custom Preview Bar
=======================

The custom preview bar with the dropdown of all your items.

Fully configurable via one single file (config.php).

[See the demo](https://www.proteusthemes.com/themes/?theme=cargopress-wp).

### Setup

It is easy to setup this custom bar.

1. Change the settings in the config.php file
2. Copy all the files to your server

### Customize

Sure, you will want to customize your navbar. It is build with the Compass/SASS, so if it will be the easiest option to change the `preview-bar/sass/style.scss` which will be compiles to the minified CSS using `compass build`.

### Authors

Created by [ProteusThemes](https://github.com/ProteusThemes/ThemeForest-Preview-Bar)

The initial design in PSD was created by [Jaka Šmid](http://www.spaka.si/).
